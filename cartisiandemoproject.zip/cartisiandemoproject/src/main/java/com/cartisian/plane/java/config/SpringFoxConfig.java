package src.main.java.com.cartisian.plane.java.config;

import com.cartisian.plane.config.Bean;
import com.cartisian.plane.config.Configuration;
import com.cartisian.plane.config.Docket;

@Configuration
public class SpringFoxConfig {
	 @Bean
	    public Docket api() { 
	        return new Docket(DocumentationType.SWAGGER_2)  
	          .select()                                  
	          .apis(RequestHandlerSelectors.any())              
	          .paths(PathSelectors.any())                          
	          .build();                                           
	    }
	}

