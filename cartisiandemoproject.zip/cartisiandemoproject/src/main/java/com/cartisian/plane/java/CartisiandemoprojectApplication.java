package com.cartisian.plane.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartisiandemoprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartisiandemoprojectApplication.class, args);
	}

}
