package src.test.java.com.cartisian.plane.java.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartisiandemoprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
